﻿for(var i = 0; i < 220; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u133'] = 'center';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u40'] = 'top';document.getElementById('u139_img').tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('产品管理.html');

}
});
gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u147'] = 'center';document.getElementById('u167_img').tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	SetPanelState('u158', 'pd0u158','none','',500,'none','',500);

}
});
gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u194'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u96'] = 'top';document.getElementById('u204_img').tabIndex = 0;

u204.style.cursor = 'pointer';
$axure.eventManager.click('u204', function(e) {

if (true) {

	SetPanelState('u158', 'pd2u158','none','',500,'none','',500);

}
});
gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u200'] = 'center';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u48'] = 'top';document.getElementById('u209_img').tabIndex = 0;

u209.style.cursor = 'pointer';
$axure.eventManager.click('u209', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('查看入库清单.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u28'] = 'top';